package Esercizio_6;

public class Buffer extends Thread{
	
	private int count;
	private final int MAX_VALUE = 5;
	
	public Buffer() {
		count = 0;
	}
	
	public synchronized void increment() {
		count++;
	}
	
	public synchronized void decrement() {
		count--;
	}

	public int getCount() {
		return count;
	}	
}
