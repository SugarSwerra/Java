package Esercizio_6;

public class Main{

	public static void main(String[] args) {

		Buffer buffer = new Buffer();

		Runnable task1 = () -> {
			System.out.println("Thread 1 avviato...");
			for (int i = 0; i < 5; i++) {
				buffer.increment();
				System.out.println(buffer.getCount());
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};
		
		Runnable task2 = () -> {
			System.out.println("Thread 2 avviato...");
			for (int i = 0; i < 5; i++) {
				buffer.decrement();
				System.out.println(buffer.getCount());
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};

		Thread thread1 = new Thread(task1);
		Thread thread2 = new Thread(task2);

		thread1.start();
		thread2.start();
		
		try{
			thread1.join();
			thread2.join();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}

}


